﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Authentication_And_Logging
{
    
    public partial class Login : Form
    {
        private string location = @"C:\Users\Jason Richard\Desktop\file\Log.txt";
        public string user = "abc";
        public string pass = "abc";
        public Login()
        {
            InitializeComponent();
            UserNameTextBox.Focus();
            timer1.Start();
            System.DateTime.Now.DayOfWeek.ToString();
            DateTime dt = DateTime.Now;
            label5.Text = System.DateTime.Now.ToString("dddd") + ", " + DateTime.Now.ToString("MMMM") + " " + dt.Year.ToString();
        }

         public Int16 checkCredentials(String userName, String password)
        { 
            Int16 successFlag = 0;
            if (userName.ToLower().Equals(user) && password.Equals(pass))
            { 
                successFlag = 1;
            }
            else
            {
                if (String.IsNullOrEmpty(userName.Trim()) || String.IsNullOrEmpty(password.Trim()))
                {
                    successFlag = -1;
                }
                else
                {
                    successFlag = 0;
                }
            }
            return successFlag;
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            label6.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserNameTextBox.Text = "";
            PasswordTextBox.Text = "";
        }

        private void UserNameTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void PasswordTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(UserNameTextBox.Text =="")
            {
                MessageBox.Show("Username input must not be Empty ", "UserName Empty", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(PasswordTextBox.Text=="")
            {
                MessageBox.Show("Password input must not be Empty ", "Password Empty", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(UserNameTextBox.Text==user && PasswordTextBox.Text==pass)
            {
                
                if (!File.Exists(location))
                {
                    MessageBox.Show("Your Log File does not exist ", "Log File not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    StreamWriter writer = new StreamWriter(location, true);
                    DateTime dt = DateTime.Now;
                    writer.WriteLine(UserNameTextBox.Text + "\t" + dt+"\t\t"+ "Successful Login");
                    writer.Dispose();
                }
                MessageBox.Show("You are Logged in Successfully ", "Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                StreamWriter writer = new StreamWriter(location, true);
                DateTime dt = DateTime.Now;
                writer.WriteLine(UserNameTextBox.Text + "\t" + dt + "\t\t" + "UnSuccessful Login");
                writer.Dispose();
                MessageBox.Show("Login Details Are not correct please try again ", "UnSuccessfull", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

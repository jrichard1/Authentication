﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Authentication_And_Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication_And_Logging.Tests
{
    [TestClass()]
    public class LoginTests 
    {
        [TestMethod()]
        public void CorrectPasswordTest()
        {
            Login obj = new Login();
            Int16 result = obj.checkCredentials("abc","abc");
            Assert.IsTrue(result == 1);
        }

        [TestMethod()]
        public void ValiduserInvalidPassword()
        {
            Login obj = new Login();
            Int16 result = obj.checkCredentials("abc", "xyz");
            Assert.IsTrue(result == 0);
        }

        [TestMethod()]
        public void EmptyusernamevalidPassword()
        {
            Login obj = new Login();
            Int16 result = obj.checkCredentials(" ", "abc");
            Assert.IsTrue(result == -1);
        }

        [TestMethod()]
        public void EmptyUserNameAndEmptyPassword()
        {
            Login obj = new Login();
            Int16 result = obj.checkCredentials(" ", " ");
            Assert.IsTrue(result == -1);
        }

        [TestMethod()]
        public void EmptyUserNameAndWrongPassword()
        {
            Login obj = new Login();
            Int16 result = obj.checkCredentials(" ", "xyz");
            Assert.IsTrue(result == -1);
        }

        [TestMethod()]
        public void InvalisUserNameAndValidPassword()
        {
            Login obj = new Login();
            Int16 result = obj.checkCredentials("xyz", "abc");
            Assert.IsTrue(result == 0);
        }

        [TestMethod()]
        public void InvalidUserNameAndEmptyPassword()
        {
            Login obj = new Login();
            Int16 result = obj.checkCredentials("xyz", " ");
            Assert.IsTrue(result == -1);
        }

        [TestMethod()]
        public void InvalidUserNameAndInvalidPassword()
        {
            Login obj = new Login();
            Int16 result = obj.checkCredentials("xyz", "xyz");
            Assert.IsTrue(result == 0);
        }

        [TestMethod()]
        public void ValidTheTest()
        {
            try
            {
                Login obj = new Login();
            }
            catch
            {
                Assert.Fail();
            }
        }
    }
}